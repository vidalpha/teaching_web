package be.unamur.interfaces;

public interface INotificationService {

	void send();

}
