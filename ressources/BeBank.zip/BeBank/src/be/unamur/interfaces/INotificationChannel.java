package be.unamur.interfaces;

public interface INotificationChannel {
	
	void process();
}
